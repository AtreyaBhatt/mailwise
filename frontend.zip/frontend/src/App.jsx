import React, { useState, useEffect } from "react";
import axios from "axios";

const PRIORITY_LABELS = {
  1: "Very Low",
  2: "Low",
  3: "Medium",
  4: "High",
  5: "Very High",
};

const PRIORITY_COLORS = {
  1: "#808080",
  2: "#3fc380",
  3: "#f7ca18",
  4: "#fd7e14",
  5: "#dc3545",
};

function App() {
  const [accessToken, setAccessToken] = useState("");
  const [emails, setEmails] = useState([]);
  const [error, setError] = useState("");
  const [priorityFilter, setPriorityFilter] = useState([]);
  const [loading, setLoading] = useState(false);

  // Handle Google login redirect callback
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const at = params.get("access_token");
    if (at) {
      setAccessToken(at);
      window.history.replaceState({}, document.title, "/");
    }
  }, []);

  // Redirect user to backend Google OAuth login
  const handleGoogleLogin = () => {
    window.location.href = "http://localhost:8000/auth/google/login";
  };

  // Fetch emails from backend using access token
  const fetchEmails = async () => {
    setLoading(true);
    try {
      const res = await axios.post("http://localhost:8000/api/emails", {
        access_token: accessToken,
        max_results: 20,
      });
      setEmails(res.data);
      setError("");
    } catch (err) {
      setError("Failed to fetch emails.");
    }
    setLoading(false);
  };

  // Filter emails by selected priorities
  const filteredEmails =
    priorityFilter.length === 0
      ? emails
      : emails.filter((email) => priorityFilter.includes(email.priority));

  // Sidebar filter toggle
  const handlePriorityToggle = (priority) => {
    setPriorityFilter((prev) =>
      prev.includes(priority)
        ? prev.filter((p) => p !== priority)
        : [...prev, priority]
    );
  };

  return (
    <div
      style={{
        display: "flex",
        minHeight: "100vh",
        background: "#181a1b",
        color: "#f7f7fa",
        fontFamily: "Inter, Arial, sans-serif",
      }}
    >
      {/* Sidebar */}
      <aside
        style={{
          width: 200,
          background: "#232526",
          padding: "2rem 1rem",
          borderRight: "1px solid #222",
          minHeight: "100vh",
        }}
      >
        <div style={{ fontWeight: 700, marginBottom: 24, fontSize: "1.1rem" }}>
          Filters
        </div>
        <div>
          <div style={{ fontSize: 14, marginBottom: 10, opacity: 0.7 }}>
            Priority
          </div>
          {Object.entries(PRIORITY_LABELS).map(([priority, label]) => (
            <label
              key={priority}
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: 8,
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={priorityFilter.includes(Number(priority))}
                onChange={() => handlePriorityToggle(Number(priority))}
                style={{ marginRight: 8 }}
              />
              <span
                style={{
                  background: PRIORITY_COLORS[priority],
                  color: "#222",
                  padding: "2px 8px",
                  borderRadius: 6,
                  fontWeight: 600,
                  fontSize: 13,
                  marginRight: 8,
                  minWidth: 60,
                  textAlign: "center",
                  display: "inline-block",
                }}
              >
                {label}
              </span>
            </label>
          ))}
        </div>
      </aside>

      {/* Main Content */}
      <main
        style={{
          flex: 1,
          padding: "2rem 4vw",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <h2 style={{ marginBottom: 24, fontWeight: 700, fontSize: "1.5rem" }}>
          EmailWise
        </h2>
        {!accessToken ? (
          <button
            onClick={handleGoogleLogin}
            style={{
              background: "#4285f4",
              color: "white",
              border: "none",
              borderRadius: 6,
              padding: "0.7rem 2rem",
              fontSize: "1.1rem",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Sign in with Google
          </button>
        ) : (
          <>
            <button
              onClick={fetchEmails}
              disabled={loading}
              style={{
                background: "#fd5c63",
                color: "white",
                border: "none",
                borderRadius: 6,
                padding: "0.7rem 2rem",
                fontSize: "1.1rem",
                fontWeight: 600,
                cursor: "pointer",
                marginBottom: 24,
              }}
            >
              {loading ? "Loading..." : "Fetch Emails"}
            </button>
            {error && (
              <div style={{ color: "#fd5c63", marginBottom: 20 }}>{error}</div>
            )}
            {filteredEmails.length > 0 && (
              <table
                style={{
                  width: "100%",
                  maxWidth: 700,
                  borderCollapse: "collapse",
                  background: "#232526",
                  borderRadius: 8,
                  overflow: "hidden",
                  color: "#f7f7fa",
                  fontSize: 15,
                }}
              >
                <thead>
                  <tr
                    style={{
                      background: "#202124",
                      color: "#fd5c63",
                      textAlign: "left",
                    }}
                  >
                    <th style={{ padding: "0.7rem 0.5rem" }}>Sender</th>
                    <th style={{ padding: "0.7rem 0.5rem" }}>Summary</th>
                    <th style={{ padding: "0.7rem 0.5rem" }}>Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmails
                    .sort((a, b) => b.priority - a.priority)
                    .map((email, idx) => (
                      <tr key={idx}>
                        <td style={{ padding: "0.7rem 0.5rem" }}>
                          {email.sender}
                        </td>
                        <td style={{ padding: "0.7rem 0.5rem" }}>
                          {email.summary}
                        </td>
                        <td style={{ padding: "0.7rem 0.5rem" }}>
                          <span
                            style={{
                              background:
                                PRIORITY_COLORS[email.priority] || "#888",
                              color: "#222",
                              borderRadius: "8px",
                              padding: "2px 10px",
                              fontWeight: "bold",
                              fontSize: "0.95em",
                              display: "inline-block",
                              minWidth: 70,
                              textAlign: "center",
                            }}
                          >
                            {PRIORITY_LABELS[email.priority] ||
                              email.priority}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            )}
            {filteredEmails.length === 0 && emails.length > 0 && (
              <div style={{ opacity: 0.7, marginTop: 40 }}>
                No emails match the selected filters.
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default App;